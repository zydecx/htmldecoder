\\author\\zydecx
\\authorurl\\https://github.com/zydecx
\\date\\2015-10-03 23:50
\\modified\\2015-10-03 23:50
\\category\\document
\\tags\\
\\abstract\\
\\enabled\\true
\\title\\Htmldecoder Project

## `htmldecoder` Project

### What's `htmldecoder`

`htmldecoder` is a simple static site generator. With it, you could just focus on your content and free from trivial matters like pagination/category/tag/search/... `htmldecoder` now is stepping out its first stage, you're welcomed to join to make it better.

`htmldecoder` is developed with Java and compiled with jdk1.7. Older versions of jdk might not work. Project is arranged using Maven and can be packaged as a jar file to run(several dependency jars should included into classpath).

### Getting Start

Below gives a few steps to get start.

For users, learn

* [Get `htmldecoder`]({{site_url}}/staticpage/-6-Document/-1-Getting%20Start/-1-Users/-1-get%20htmldecoder.html)
* [Write an article]({{site_url}}/staticpage/-6-Document/-1-Getting%20Start/-1-Users/-2-write%20an%20article.html)
* [Generate the site]({{site_url}}/staticpage/-6-Document/-1-Getting%20Start/-1-Users/-3-generate%20site.html)


For developers, learn

* [Backgrounds]({{site_url}}/staticpage/-6-Document/-1-Getting%20Start/-2-Developers/-1-backgrounds.html)
* [Set up `htmldecoder`]({{site_url}}/staticpage/-6-Document/-1-Getting%20Start/-2-Developers/-2-set%20up%20htmldecoder.html)

### Learn More

To learn more about `htmldecoder`, refer to document page.	


### Document

* Getting start

	* Users

		* [Get `htmldecoder`]({{site_url}}/staticpage/-6-Document/-1-Getting%20Start/-1-Users/-1-get%20htmldecoder.html)
		* [Write an article]({{site_url}}/staticpage/-6-Document/-1-Getting%20Start/-1-Users/-2-write%20an%20article.html)
		* [Generate the site]({{site_url}}/staticpage/-6-Document/-1-Getting%20Start/-1-Users/-3-generate%20site.html)

	* Developers

		* [Backgrounds]({{site_url}}/staticpage/-6-Document/-1-Getting%20Start/-2-Developers/-1-backgrounds.html)
		* [Set up `htmldecoder`]({{site_url}}/staticpage/-6-Document/-1-Getting%20Start/-2-Developers/-2-set%20up%20htmldecoder.html)

* [Article]({{site_url}}/staticpage/-6-Document/-2-article/index.html)
* [Static Page]({{site_url}}/staticpage/-6-Document/-3-static%20page/index.html)
* [Tag&Category]({{site_url}}/staticpage/-6-Document/-4-tag&category/index.html)
* [Theme]({{site_url}}/staticpage/-6-Document/-5-theme/index.html)
* [Configure More]({{site_url}}/staticpage/-6-Document/-6-configure%20more/index.html)
* [Directory Convertions]({{site_url}}/staticpage/-6-Document/-7-directory%20conversions/index.html)



