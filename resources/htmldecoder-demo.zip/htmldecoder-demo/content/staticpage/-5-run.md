\\author\\zydecx
\\authorurl\\https://github.com/zydecx
\\date\\2015-10-04 16:00
\\modified\\2015-10-04 16:00
\\category\\document
\\tags\\
\\abstract\\
\\enabled\\true
\\title\\Run

## Run `htmldecoder`

To run `htmldecoder`, open terminal(Linux) or CMD(Windows) and switch to the root directory of code. Put your site pages under `{workspace directory}/content`, run the command below to run:

	java -jar htmldecoder-{version}.jar {path of configuration file}

And site pages will be outputed to `{workspace directory}/output`. Upload all the resourses generated to your site server.
 
