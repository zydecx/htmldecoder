\\author\\zydecx
\\authorurl\\https://github.com/zydecx
\\date\\2015-10-04 16:00
\\modified\\2015-10-04 16:00
\\category\\document
\\tags\\
\\abstract\\
\\enabled\\true
\\title\\Download

## Download `htmldecoder`

`htmldecoder` is now available for downloading. You could create you own static page site with it.

### System Requirements

 Condition | Requirement 
 --------------------------|--------------------
 Java Development Kit(JDK) | JDK 1.7 or above
 Maven | Maven 3.0 or above(older versions have not tested)

### Files

You can download lastest stable version of `htmldecoder` from [Here]({{site_url}}/resources/htmldecoder-latest.zip). It provides zip file of `htmldecoder` jar and jars it depends on.

If you are a programmer who is familiar with Java, you could just download the lastest version of code from [Here](https://github.com/zydecx/htmldecoder/archive/master.zip). It's also recommended to clone the latest code from project repository in GitHub: [https://github.com/zydecx/htmldecoder](https://github.com/zydecx/htmldecoder).

