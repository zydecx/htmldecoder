\\author\\zydecx
\\authorurl\\https://github.com/zydecx
\\date\\2015-10-04 16:00
\\modified\\2015-10-04 16:00
\\category\\document
\\tags\\
\\abstract\\
\\enabled\\true
\\title\\About HtmlDecoder

## What's `htmldecoder`

`htmldecoder` is a simple static site generator. With it, you could just focus on your content and free from trivial matters like pagination/category/tag/search/... `htmldecoder` now is stepping out its first stage, you're welcomed to join to make it better.

`htmldecoder` is developed with Java and compiled with jdk1.7. Older versions of jdk might not work. Project is arranged using Maven and can be packaged as a jar file to run(several dependency jars should included into classpath).

<!--htmldecoder:more-->


