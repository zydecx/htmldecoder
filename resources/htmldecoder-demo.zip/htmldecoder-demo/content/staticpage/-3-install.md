\\author\\zydecx
\\authorurl\\https://github.com/zydecx
\\date\\2015-10-04 16:00
\\modified\\2015-10-04 16:00
\\category\\document
\\tags\\
\\abstract\\
\\enabled\\true
\\title\\Install

## Install `htmldecoder`

There is no formal demand for installation. If your computer satisfies the requirements in download page, you could just be ready to configure and run.

* If you download the zip file of jars, just unzip them to the disk.
* If you download the lastest version of code, do as the following steps:

	1. unzip code to disk
	2. open terminal(Linux) or CMD(Windows) and switch to the root directory of code
	3. package `htmldecoder` with command below:

			mvn clean package -Dmaven.test.skip=true 
	
After steps above, you'll get the following files:

	{ROOT_PATH}
	|--htmldecoder-0.2.1004.jar
	`--dependency-lib
	   |--jackson-core-asl-1.9.13.jar
	   |--jackson-mapper-asl-1.9.13.jar
	   |--junit-4.1.jar
	   |--log4j-1.2.17.jar
	   |--slf4j-api-1.7.7.jar
	   `--slf4j-log4j12-1.7.7.jar

