\\author\\zydecx
\\authorurl\\https://github.com/zydecx
\\date\\2015-10-04 16:00
\\modified\\2015-10-04 16:00
\\category\\document
\\tags\\
\\abstract\\
\\enabled\\true
\\title\\Configure

## Configure `htmldecoder`

For `htmldecoder`, configurations are all stored in a single properties file. So before running, create a properties file with name like `configuration.properties`. Below shows a simple format of this file.

	site_url=http://zydecx.github.io

	# messages shown in header
	site_title=Modernist
	site_description=A Theme for GitHub Pages
	site_github_home=#

	# root path of workspace
	workspace=.

<!--htmldecoder:more-->

For details of configuration above,

* `site_url` Url of site to be pulished
* `site_title` Title of site, shown at the header of site
* `site_description` Brief description of site, typical a piece of small sentence shown below `site_title`
* `site_github_home` Url of personal GitHub page
* `workspace` Path of directory to do the transform work, i.g. C:/personalSite

More information can be accessed in the document part.

