\\author\\zydecx
\\authorurl\\https://github.com/zydecx
\\date\\2015-10-04 17:36
\\modified\\2015-10-04 17:36
\\category\\document
\\tags\\
\\abstract\\
\\enabled\\true
\\title\\Project Backgrounds

## Project Backgrounds

### Backgrounds

The starting point of `htmldecoder` project is really simple-making blog writing more convenient. Nowadays, there're really so many ways to write blog. You could use public blog service provider, you could also get your own server and build with wordpress. I really don't like the first one as you should only do what they let you do and write in browser within a textarea. I've tried wordpress. Yes, you are free to do what you want, accessing database, changing styles. It's just a little bit time costing and money costing to maintain a server and a domain. By chance, I get to know pelican and Jekyll. They provide me a new view on blog site. I really appriciate their work. Unfortunatly, I fail to start it up. So getting bored by environment configuration, I decide to write my own, with Java.

As said above, the starting point is simple. Bloggers do care about styles. But within a period of time, the sense of style is stable. So we should focus more on content, while on the other side, the blog could easily have a united style. Without dynamic language, there really comes some trouble. To overcome it, we build wheels.

### Knowledge Requirements

For those who want to participate in the project, there're some knowledge requirements. Here is the list:

* Java
* JavaScript
* JQuery
* CSS
* Html
* Maven

The project is arranged with Maven, it's required to know how to build, package and install with it. Java is the main language to develop `htmldecoder`. You should be familar with it and some knowledge to design pattern is a plus. `htmldecoder` is designed based on theme. A theme is a collection of templates to format structure and styles of title, article, nav, pagination... They are designed with Html/CSS/JavaScript/JQuery.

