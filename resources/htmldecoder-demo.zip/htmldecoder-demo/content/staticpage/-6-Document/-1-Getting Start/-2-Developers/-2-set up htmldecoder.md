\\author\\zydecx
\\authorurl\\https://github.com/zydecx
\\date\\2015-10-04 17:36
\\modified\\2015-10-04 17:36
\\category\\document
\\tags\\
\\abstract\\
\\enabled\\true
\\title\\Set Up htmldecoder

## Set Up `htmldecoder`

### Dowload Package

You can download lastest version of `htmldecoder` from [Here](https://github.com/zydecx/htmldecoder/archive/master.zip). It's also recommended to clone the latest code from project repository in GitHub: [https://github.com/zydecx/htmldecoder](https://github.com/zydecx/htmldecoder).

### Install Package

`htmldecoder` is a maven project. Setting up is easy. Open terminal(Linux) or CMD(Windows) and switch to the root directory of code. Using command below to package it.

	mvn clean package -Dmaven.test.skip=true

To develop in IDE, like Eclipse, run the following command and import the project into Eclipse. You can find the main function in `com.debugtoday.htmldecoder.HtmlDecoderJob`.
		
	mvn clean install eclipse:eclipse

