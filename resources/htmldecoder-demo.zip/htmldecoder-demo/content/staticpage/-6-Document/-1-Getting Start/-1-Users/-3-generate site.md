\\author\\zydecx
\\authorurl\\https://github.com/zydecx
\\date\\2015-10-04 17:36
\\modified\\2015-10-04 17:36
\\category\\document
\\tags\\
\\abstract\\
\\enabled\\true
\\title\\Generate Site

## Generate Site


### Configure `htmldecoder`

For `htmldecoder`, configurations are all stored in a single properties file. So before running, create a properties file with name like `configuration.properties` under workspace directory. Below shows a simple format of this file.

	site_url=http://zydecx.github.io

	# messages shown in header
	site_title=Modernist
	site_description=A Theme for GitHub Pages
	site_github_home=#

	# root path of workspace
	workspace=.

<!--htmldecoder:more-->

### Output Site

Open terminal(Linux) or CMD(Windows) and switch to the root directory of package. Run the command below to output site:

	java -jar htmldecoder-{version}.jar {path of configuration file}

And site pages will be outputed to `{workspace directory}/output`. You can view it on your own computer or upload to your site server.

