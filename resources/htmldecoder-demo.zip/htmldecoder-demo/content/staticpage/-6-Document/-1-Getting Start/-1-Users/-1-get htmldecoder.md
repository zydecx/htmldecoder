\\author\\zydecx
\\authorurl\\https://github.com/zydecx
\\date\\2015-10-04 17:36
\\modified\\2015-10-04 17:36
\\category\document
\\tags\\
\\abstract\\
\\enabled\\true
\\title\\Get htmldecoder

## Get `htmldecoder`

### Dowload Package

You can download lastest stable version of `htmldecoder` from [Here]({{site_url}}/resources/htmldecoder-latest.zip). It provides zip file of `htmldecoder` jar and jars it depends on.

## Install Package

There is no formal demand for installation. If your computer satisfies the requirements in download page, you could just be ready to configure and run.

The only thing you need to do as to create a workspace directory, i.g. C:/personalSite.  Unzip the zip package downloaded to the workspace directory. And you'll get the following files:

	{WORKSPACE}
	|--htmldecoder-{version}.jar
	`--dependency-lib
	   |--jackson-core-asl-1.9.13.jar
	   |--jackson-mapper-asl-1.9.13.jar
	   |--junit-4.1.jar
	   |--log4j-1.2.17.jar
	   |--slf4j-api-1.7.7.jar
	   `--slf4j-log4j12-1.7.7.jar

### Create Content Directory

Create content directory named `content` under workspace directory. The directory is ready for site pages. 