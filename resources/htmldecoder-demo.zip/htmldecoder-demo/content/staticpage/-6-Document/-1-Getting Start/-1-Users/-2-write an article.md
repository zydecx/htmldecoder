\\author\\zydecx
\\authorurl\\https://github.com/zydecx
\\date:2015-10-04 17:36
\\modified:2015-10-04 17:36
\\category\\document
\\tags\\
\\abstract\\
\\enabled\\true
\\title\\Write an Article

## Write an Article

Under `{workspace directory}/content`, create a new article file, i.g. about.html. A typical format of article is shown as below.

	<!doctype html>
	<html>
	  <head>
	    <meta charset="utf-8">
	
	    <meta name="htmldecoder:date" content="2015-10-02 23:30">
	    <meta name="htmldecoder:modified" content="2015-10-02 23:30">
	    <meta name="htmldecoder:author" content="zydecx">
	    <meta name="htmldecoder:authorurl" content="https://github.com/zydecx">
	    <meta name="htmldecoder:category" content="article">
	    <meta name="htmldecoder:tags" content="Help">
	    <meta name="htmldecoder:abstract" content="">
	    <meta name="htmldecoder:enabled" content="true">
	    <title>Welcome to GitHub Pages</title>
	  </head>
	  <body>
	    <h3>
	    <a id="welcome-to-github-pages" class="anchor" href="#welcome-to-github-pages" aria-hidden="true"><span class="octicon octicon-link"></span></a>Welcome to GitHub Pages.</h3>
		<!--htmldecoder:more-->
	
	    <p>This automatic page generator is the easiest way to create beautiful pages for all of your projects. Author your page content here <a href="https://guides.github.com/features/mastering-markdown/">using GitHub Flavored Markdown</a>, select a template crafted by a designer, and publish. After your page is generated, you can check out the new <code>gh-pages</code> branch locally. If you’re using GitHub Desktop, simply sync your repository and you’ll see the new branch.</p>
	        
	  </body>
	</html>

The sample shows a simple format of article. Most information of the article is defined in `<meta>` element. There's also a comment under `<body>` element:`<!--htmldecoder:more-->`. When making pagination of articles, only content before this element will be extracted as excerpt to display. It'll still work even without this element, only that the whole article content will be displayed.

