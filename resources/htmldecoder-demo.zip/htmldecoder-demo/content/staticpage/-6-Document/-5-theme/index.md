\\author\\zydecx
\\authorurl\\https://github.com/zydecx
\\date\\2015-10-05 13:34
\\modified\\2015-10-05 13:34
\\category\\document
\\tags\\
\\abstract\\
\\enabled\\true
\\title\\Theme

## Theme

### About Theme

A theme contains a collection of template and relative style or script files. Each template stucts one part of the page, i.g. nav, search page, pagination...

Templates are written by HTML(ends with .html or .htm).

Each theme also contains a marked file --`META`.

### Customerize Theme

So far, `htmldecoder` contains two theme: [default](http://zydecx.github.io/modernist/index_zydecx.html) and [steady](http://zydecx.github.io/modernist/index_zydecx_steady.html). Click to redirect to demo page.

Customerize theme by adding configuration `current_theme=steady`. This will update current theme to steady.

### Build Own Theme

It's possible to build your own theme. A simple way is to make directory `theme/your-theme-name` under workspace. To get started, you can copy the default theme to your theme directory and make some modification. Remember to add configuration to your theme.


