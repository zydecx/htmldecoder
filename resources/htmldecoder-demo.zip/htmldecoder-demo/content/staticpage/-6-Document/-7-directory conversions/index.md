\\author\\zydecx
\\authorurl\\https://github.com/zydecx
\\date\\2015-10-05 12:18
\\modified\\2015-10-05 12:18
\\category\\document
\\tags\\
\\abstract\\
\\enabled\\true
\\title\\Directory Conversions


## Typical Directory Structure

All work can be done under workspace directory. A typical directory structure is as shown below.

<!--htmldecoder:more-->

	{workspace directory}
	|--htmldecoder-0.2.1004.jar
	|--dependency-lib
	|  |--jackson-core-asl-1.9.13.jar
	|  |--jackson-mapper-asl-1.9.13.jar
	|  |--junit-4.1.jar
	|  |--log4j-1.2.17.jar
	|  |--slf4j-api-1.7.7.jar
	|  `--slf4j-log4j12-1.7.7.jar
	|--configuration.properties
	|--Content
	|  |--index.html
	|  |--article1.html
	|  |--...
	|  |--article_folder3
	|  |  |--article32.html
	|  |  `--article_folder4
	|  |     `--article33.html
	|  |--images
	|  |  `--logo.png
	|  `--staticpage
	|     |--Life
	|     |  |--index.html
	|     |  `--donation.html
	|     `About.html
	`--Output
	   |--images
	   |  `--logo.png
	   |--index.html
	   |--search.html
	   |--article1.html
	   |--...
	   |--article_folder3
	   |  |--article32.html
	   |  `--article_folder4
	   |     `--article33.html
	   |--page
	   |  |--index.html
	   |  `--page
	   |     `--2
	   |        `--index.html
	   |--staticpage
	   |  |--Life
	   |  |  |--index.html
	   |  |  `--donation.html
	   |  `About.html
	   |--tag
	   |  |--index.html
	   |  |--tag1
	   |  |--...
	   |  |--tag32
	   |  |  |--index.html
	   |  |  `--page
	   |  |     `--2
	   |  |        `--index.html
	   |  `--page
	   |     |--index.html
	   |     `--page
	   |        `--2
	   |           `--index.html
	   `--category
	      |--index.html
	      |--category1
	      |  `--index.html
	      |--category2
	         |--index.html
	         `--page
	            `--2
	               `--index.html

