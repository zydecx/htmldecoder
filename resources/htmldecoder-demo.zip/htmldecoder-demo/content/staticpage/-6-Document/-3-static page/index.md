\\author\\zydecx
\\authorurl\\https://github.com/zydecx
\\date\\2015-10-04 23:42
\\modified\\2015-10-04 23:42
\\category\\document
\\tags\\
\\abstract\\
\\enabled\\true
\\title\\Static Page

## Static Page

There may be some confusations when meeting static pages. In fact, static page and article are alike, including writing styles, title and meta. Here we discuss some differences of static page from article.

### Where to Write

Write static pages under `{workspace directory}/staticpage`. The folder can also be customerized, which will be discussed in Configuration part.

<!--htmldecoder:more-->

### No More Tag

Unlike article, static page only displays as a whole part and will not display in pagination. So more tag is useless in static page.

### Excluded from Recent Nav

Static pages are also excluded from Recent nav. There you can only read recent articles.

### Where to Display

There's special space to display static pages. Mostly, it locates under header of webpage, above article content. Each static page has an anchor there where you can click to redirect to the page.

Static pages allow multiple levels. You could just create a folder and put some pages under that folder. The folder will also have it's anchor at the special space of webpage. If there's an `index.html` or `index.htm` under the folder, the folder's anchor will redirect to the index file. 

### Customerize Display Order

If filename of static page file or folder is with format `-i-name`, `htmldecoder` will order them by `i` and display with `name`(folder only, for a file, use `<title>`). 

### Conclusion

Focus on the differences from article, you will have better knowledge of static page.


