\\author\\zydecx
\\authorurl\\https://github.com/zydecx
\\date\\2015-10-05 15:08
\\modified\\2015-10-05 15:08
\\category\\document
\\tags\\
\\abstract\\
\\enabled\\true
\\title\\Configure More

## Configure More

Below is the list of full configurations.

<!--htmldecoder:more-->

Name | Description
-----| -----------
site_url | Url of site to be pulished
site_title | Title of site, shown at the header of site
site_description | Brief description of site, typical a piece of small sentence shown below `site_title`
site_github_home | Url of personal GitHub page
home_static_title | By default, `Home` is set as the first static page shown. This configure the display name
tag_title | title of nav tag
category_title | title of nav category
recent_title | title of nav recent
search_title | title of search page
workspace | Path of directory to do the transform work, i.g. C:/personalSite
content | Name of directory to find resources. It's under workspace path. 
output | Name of directory to output site. It's under workspace path. 
staticpage | Name of directory to find staticpage. It's under content path. 
theme | Name of directory to find theme. It's under workspace path. 
current_theme | Current theme name, now support `default` and `steady`
search_engine | Search engine of site, now support `google`
google_customer_search_id | If use `google` as search engine, you must get google customer search id
ignore_list | List of filename to be ignored from decoding. Different filenames are separated by `,`. File/Directory with name listed here under content path will be ignored. 
default_pagination | Default pagination size, used for article pagination. If not set, use 20.
tag_pagination | Pagination size for tag page. If not set, use 20.
category_pagination | Pagination size for category page. If not set, use 20. 
nav_tag_enabled | If display nav tag, default true.
nav_category_enabled | If display nav category, default true.
nav_recent_enabled | If display nav recent, default true.
nav_search_enabled | If display nav search, default false. If set true, set search engine.
article_header_enabled | If display article header, like title, tag, category, etc, default true.
markdown_interpreter | interpreter for markdown file. Now support `pandoc`. Put it empty if no markdown files used.
markdown_interpreter_pandoc | path of pandoc command


