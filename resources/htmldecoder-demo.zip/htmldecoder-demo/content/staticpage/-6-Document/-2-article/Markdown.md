\\author\\zydecx
\\authorurl\\https://github.com/zydecx
\\date\\2015-10-07 16:08
\\modified\\2015-10-07 16:08
\\category\\document
\\tags\\
\\abstract\\
\\enabled\\true
\\title\\Article with Markdown

## Article with Markdown

### Basic Knowledge of Article

To get basic knowledge of article, i.g. where to write, where to find output file, refer to [Article Document]({{site_url}}/staticpage/-6-Document/-2-article/index.html).

This document mainly focus on writing format of markdown.

## Get Markdown Interpreter

To support writing with markdown, a markdown interpreter is needed. Now the only interpreter supported is `pandoc`. Refer to [official site](http://pandoc.org/) for more information about pandoc. Download and install it before using `htmldecoder`.

<!--htmldecoder:more-->

As configurations below.`markdown_interpreter_pandoc` refers to path of pandoc command. If it has been added to system environment, you can just set it as shown below. Otherwise, add full path to the execution file.

	# markdown interpreter, i.g. pandoc
	markdown_interpreter=pandoc
	
	# pandoc installation path
	markdown_interpreter_pandoc=pandoc

### Title and Meta Information

Title and meta information provides important information about article, i.g. when created, by whom, etc.

For writing with markdown, put meta information on the top. Each meta information occupies a line, with format of `\\meta-name\\meta-value`.

Meta information tells more about the article, i.g. when created, by whom, etc. Details of meta available now is shown below.

Meta | Description
-----| -----------
date | create time of article, format like 2015-10-05 00:03; If not set, replaced by create time of file
modified | last modified time of article, format like 2015-10-05 00:03; If not set, replaced by create time of file
author | author of article
authorurl | personal web site of author
category | category, multiple categories can be separated by ','
tags | tag, multiple tags can be separated by ','
abstract | abstract
enabled | if use template to format current article; If false, file will be copied to output folder directly

Use these meta information to better orgnize your article and help readers learn more information.

Specially, `title` will output as `<title>` in the end. You CANNOT leaves it empty, otherwise there may encounter display or generating problems. What's more, title, rather than file name, will be used to format header part of the article automatically.

### More Tag

For pages like pagination, it's more friendly to display only part of an article rather than the whole article. So more tag is imported for such situations. Put `<!--htmldecoder:more-->` in your article. And content before this tag  will be extracted as excerpt to display in pagination pages. If not set, the whole article will be displayed. 

### A Typical Article

A typical format of article with markdown is shown as below.

		\\\\\\\\author\\\\\\\\zydecx
		\\\\\\\\authorurl\\\\\\\\https://github.com/zydecx
		\\\\\\\\date\\\\\\\\2015-10-03 23:50
		\\\\\\\\modified\\\\\\\\2015-10-03 23:50
		\\\\\\\\category\\\\\\\\document
		\\\\\\\\tags\\\\\\\\
		\\\\\\\\abstract\\\\\\\\
		\\\\\\\\enabled\\\\\\\\true
		\\\\\\\\title\\\\\\\\Htmldecoder Project
		
		\#\# `htmldecoder` Project
		
		\#\#\# What's `htmldecoder`
		
		`htmldecoder` is a simple static site generator. With it, you could just focus on your content and free from trivial matters like pagination/category/tag/search/... `htmldecoder` now is stepping out its first stage, you're welcomed to join to make it better.
	
		<!--htmldecoder:more-->
		
		`htmldecoder` is developed with Java and compiled with jdk1.7. Older versions of jdk might not work. Project is arranged using Maven and can be packaged as a jar file to run(several dependency jars should included into classpath).




