\\author\\zydecx
\\authorurl\\https://github.com/zydecx
\\date\\2015-10-04 23:42
\\modified\\2015-10-04 23:42
\\category\\document
\\tags\\
\\abstract\\
\\enabled\\true
\\title\\Article

## Article

Just as the name says, article is what you writes.

### Where to Write

Write articles under `{workspace directory}/content`. In fact, the folder can be customerized, which will be discussed in Configuration part.

### Writing Style

In `htmldecoder`, article mainly focus on content, and theme/template works on style matters. So an article file should avoid complicated styles or scripts, as well as duplicated or conflicted styles or scripts to template.  Only html/htm format is supported so far. It's recommended that:

1. `<head>` only contains title and meta information of article(as will discuss below).
2. `<body>` only contains core part of your writing, without redundant decorations like `<div class="container">`.

Actually, `htmldecoder` will insert your `<head>` into template head and your `<body>` into template's specified area. For users who have good knowledge about web development, you can use this trick to add effcts that template  doesn't provide to your article; 

### Title and Meta Information

Title and meta information provides important information about article, i.g. when created, by whom, etc.

#### Title

Title uses typical HTML `<title>` element. You CANNOT leaves it empty, otherwise there may encounter display or generating problems. 

Title, instead of file name, will be used to format header part of the article automatically.

#### Meta

Meta information tells more about the article, i.g. when created, by whom, etc. Details of meta available now is shown below.

Meta | Description
-----| -----------
htmldecoder:date | create time of article, format like 2015-10-05 00:03; If not set, replaced by create time of file
htmldecoder:modified | last modified time of article, format like 2015-10-05 00:03; If not set, replaced by create time of file
htmldecoder:author | author of article
htmldecoder:authorurl | personal web site of author
htmldecoder:category | category, multiple categories can be separated by ','
htmldecoder:tags | tag, multiple tags can be separated by ','
htmldecoder:abstract | abstract
htmldecoder:enabled | if use template to format current article; If false, file will be copied to output folder directly

Use these meta information to better orgnize your article and help readers learn more information.
 
Write meta in `<header>` with format like `<meta name="htmldecoder:date" content="2015-10-02 23:30">`.

### More Tag

For pages like pagination, it's more friendly to display only part of an article rather than the whole article. So more tag is imported for such situations. Put `<!--htmldecoder:more-->` in your article. And content before this tag in `<body>` will be extracted as excerpt to display in pagination pages. If not set, the whole article will be displayed. 

### Where to Find Output File

The directory structure will be copied when output the article. 

i.g. you put an article at `{workspace directory}/content/2015/diary-1005.html`. After run `htmldecoder`, you'll find it at `{workspace directory}/output/2015/diary-1005.html`.

In this case, if your site url is `http://life.of.me`. When publish to your site, you can access your article by `http://life.of.me/2015/diary-1005.html`.

Below is a typical directory structure of outputed artilce.

	{workspace directory}
	`--Output
	   |--index.html
	   |--article1.html
	   |--...
	   |--article_folder3
	   |  |--article32.html
	   |  `--article_folder4
	   |     `--article33.html
	   `--page
	      |--index.html
	      `--page
	         `--2
	            `--index.html

Except that each article has same directory structure as in content directory, a `page` folder may be also created in case that article number exceeds pagination size. Each page has its directory and `index.html`. The first page can be accessed at `page/index.html`.

### A Typical Article

A typical format of article is shown as below.

	<!doctype html>
	<html>
	  <head>
	    <meta charset="utf-8">
	
	    <meta name="htmldecoder:date" content="2015-10-02 23:30">
	    <meta name="htmldecoder:modified" content="2015-10-02 23:30">
	    <meta name="htmldecoder:author" content="zydecx">
	    <meta name="htmldecoder:authorurl" content="https://github.com/zydecx">
	    <meta name="htmldecoder:category" content="article">
	    <meta name="htmldecoder:tags" content="Help">
	    <meta name="htmldecoder:abstract" content="">
	    <meta name="htmldecoder:enabled" content="true">
	    <title>Welcome to GitHub Pages</title>
	  </head>
	  <body>
	    <h3>
	    <a id="welcome-to-github-pages" class="anchor" href="#welcome-to-github-pages" aria-hidden="true"><span class="octicon octicon-link"></span></a>Welcome to GitHub Pages.</h3>
		<!--htmldecoder:more-->
	
	    <p>This automatic page generator is the easiest way to create beautiful pages for all of your projects. Author your page content here <a href="https://guides.github.com/features/mastering-markdown/">using GitHub Flavored Markdown</a>, select a template crafted by a designer, and publish. After your page is generated, you can check out the new <code>gh-pages</code> branch locally. If you're using GitHub Desktop, simply sync your repository and you’ll see the new branch.</p>
	        
	  </body>
	</html>


