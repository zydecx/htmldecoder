\\author\\zydecx
\\authorurl\\https://github.com/zydecx
\\date\\2015-10-04 23:42
\\modified\\2015-10-04 23:42
\\category\\document
\\tags\\
\\abstract\\
\\enabled\\true
\\title\\Article

## Article

Just as the name says, article is what you writes.

### Where to Write

Write articles under `{workspace directory}/content`. In fact, the folder can be customerized, which will be discussed in Configuration part.

### Writing Style

In `htmldecoder`, article mainly focus on content, and theme/template works on style matters. So an article file should avoid complicated styles or scripts, as well as duplicated or conflicted styles or scripts to template. `htmldecoder` supports writing of both html/htm(*.html,*.htm) and markdown(*.md) format.

<!--htmldecoder:more-->

### Where to Find Output File

The directory structure will be copied when output the article. 

i.g. you put an article at `{workspace directory}/content/2015/diary-1005.html`. After run `htmldecoder`, you'll find it at `{workspace directory}/output/2015/diary-1005.html`.

In this case, if your site url is `http://life.of.me`. When publish to your site, you can access your article by `http://life.of.me/2015/diary-1005.html`.

Specially, if you write as markdown format, i.g. `{workspace directory}/content/2015/diary-1005.md`, you'll find output file at `{workspace directory}/output/2015/diary-1005.html`.

Below is a typical directory structure of outputed artilce.

	{workspace directory}
	`--Output
	   |--index.html
	   |--article1.html
	   |--...
	   |--article_folder3
	   |  |--article32.html
	   |  `--article_folder4
	   |     `--article33.html
	   `--page
	      |--index.html
	      `--page
	         `--2
	            `--index.html

Except that each article has same directory structure as in content directory, a `page` folder may be also created in case that article number exceeds pagination size. Each page has its directory and `index.html`. The first page can be accessed at `page/index.html`.

### How to Write an Article

Depend on writing with html or markdown, writing format is different. You can get details from link below.

* [Article with Markdown]({{site_url}}/staticpage/-6-Document/-2-article/Markdown.html) 
* [Article with HTML]({{site_url}}/staticpage/-6-Document/-2-article/HTML.html) 
