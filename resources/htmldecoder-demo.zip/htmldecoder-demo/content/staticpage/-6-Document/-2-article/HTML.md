\\author\\zydecx
\\authorurl\\https://github.com/zydecx
\\date\\2015-10-07 16:26
\\modified\\2015-10-07 16:26
\\category\\document
\\tags\\
\\abstract\\
\\enabled\\true
\\title\\Article with HTML

## Article with HTML

### Basic Knowledge of Article

To get basic knowledge of article, i.g. where to write, where to find output file, refer to [Article Document]({{site_url}}/staticpage/-6-Document/-2-article/index.html).

This document mainly focus on writing format of HTML.


### Title and Meta Information

Title and meta information provides important information about article, i.g. when created, by whom, etc.

<!--htmldecoder:more-->

#### Title

Title uses typical HTML `<title>` element. You CANNOT leaves it empty, otherwise there may encounter display or generating problems. 

Title, instead of file name, will be used to format header part of the article automatically.

#### Meta

Meta information tells more about the article, i.g. when created, by whom, etc. Details of meta available now is shown below.

Meta | Description
-----| -----------
htmldecoder:date | create time of article, format like 2015-10-05 00:03; If not set, replaced by create time of file
htmldecoder:modified | last modified time of article, format like 2015-10-05 00:03; If not set, replaced by create time of file
htmldecoder:author | author of article
htmldecoder:authorurl | personal web site of author
htmldecoder:category | category, multiple categories can be separated by ','
htmldecoder:tags | tag, multiple tags can be separated by ','
htmldecoder:abstract | abstract
htmldecoder:enabled | if use template to format current article; If false, file will be copied to output folder directly

Use these meta information to better orgnize your article and help readers learn more information.
 
Write meta in `<header>` with format like `<meta name="htmldecoder:date" content="2015-10-02 23:30">`.

### More Tag

For pages like pagination, it's more friendly to display only part of an article rather than the whole article. So more tag is imported for such situations. Put `<!--htmldecoder:more-->` in your article. And content before this tag in `<body>` will be extracted as excerpt to display in pagination pages. If not set, the whole article will be displayed.  

### A Typical Article

A typical format of article with markdown is shown as below.

	<!doctype html>
	<html>
	  <head>
	    <meta charset="utf-8">
	
	    <meta name="htmldecoder:date" content="2015-10-02 23:30">
	    <meta name="htmldecoder:modified" content="2015-10-02 23:30">
	    <meta name="htmldecoder:author" content="zydecx">
	    <meta name="htmldecoder:authorurl" content="https://github.com/zydecx">
	    <meta name="htmldecoder:category" content="article">
	    <meta name="htmldecoder:tags" content="Help">
	    <meta name="htmldecoder:abstract" content="">
	    <meta name="htmldecoder:enabled" content="true">
	    <title>Welcome to GitHub Pages</title>
	  </head>
	  <body>
	    <h3>
	    <a id="welcome-to-github-pages" class="anchor" href="#welcome-to-github-pages" aria-hidden="true"><span class="octicon octicon-link"></span></a>Welcome to GitHub Pages.</h3>
		<!--htmldecoder:more-->
	
	    <p>This automatic page generator is the easiest way to create beautiful pages for all of your projects. Author your page content here <a href="https://guides.github.com/features/mastering-markdown/">using GitHub Flavored Markdown</a>, select a template crafted by a designer, and publish. After your page is generated, you can check out the new <code>gh-pages</code> branch locally. If you're using GitHub Desktop, simply sync your repository and you’ll see the new branch.</p>
	        
	  </body>
	</html>


