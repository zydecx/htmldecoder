\\author\\zydecx
\\authorurl\\https://github.com/zydecx
\\date\\2015-10-05 11:29
\\modified:2015-10-05 11:29
\\category\\document
\\tags\\
\\abstract\\
\\enabled\\true
\\title\\Tag&Category

## Tag&Category

There's really something to say what tag or category is and what's the difference. Each blogger has his own opinion on how to use them. So `htmldecoder` just provides the function, rather than tell how to use them exactly.

### What Tag/Category Provide

Regardless of function provided, tag and category(as well as directory structure) help you to better orgnize you articles. And of course, `htmldecoder` do provide somthing.

<!--htmldecoder:more-->

#### Nav

There're nav of both tag and category, where top-N most used tags and categories are displayed. Each tag or category directs you to a dependent page where lists articles under that tag or category.

Nav can be disabled by modifying configuration file. Just add `nav_tag_enabled=false` or `nav_category_enabled=false` if you don't want to use it.

Each nav has its title, by default `Tag` and `Category`. Modify it by adding configuration `tag_title=your-title` and `category_title=your-title`.

#### Tag/Category List

When having too many tags or categories, you can access a special tag/category list page where all tags/categories are displayed. You'll be redirected by this page by clicking title of tag/category nav.

Just as article pagination, tag/category can also be paged. The value by default is 20. If you want to list all tags/categories in one page, add configuration `tag_pagination` and `category_pagination` to a big value.

### Where to Find Output File

`tag` and `category` directory will be created automatically under output directory. Take tag as an example, a typical directory structure maybe like this:

	{workspace directory}
	`--Output
	   `--tag
	      |--index.html
	      |--tag1
	      |--...
	      |--tag32
	      |  |--index.html
	      |  `--page
	      |     `--2
	      |        `--index.html
	      `--page
	         |--index.html
	         `--page
	            `--2
	               `--index.html

Each tag(tag1,tag2,...,tag32) will has its own directory. If article number exceeds pagination size, `page` folder will be created and each page has its directory and `index.html`. The first page can be accessed directly under the tag folder. Similarly when tag number exceeds pagination size